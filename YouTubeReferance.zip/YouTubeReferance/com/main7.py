# pip install datacompy

import datacompy
import pandas as pd

# df1=pd.read_excel("C:\Users\vchawla\Documents\Automation\Map Trowler Secondary Project 14 June\Comparing2ExcelSheets\sheet1.xlsx")
# df2=pd.read_excel("C:\Users\vchawla\Documents\Automation\Map Trowler Secondary Project 14 June\Comparing2ExcelSheets\sheet1.xlsx")

df1 = pd.read_excel(r'C:\Users\vchawla\Documents\AssesmentQuestions\google_referance_code\YouTubeReferance\resources\Sample3.xlsx', 'Sheet1', na_values=['NA'])
df2 = pd.read_excel(r'C:\Users\vchawla\Documents\AssesmentQuestions\google_referance_code\YouTubeReferance\resources\Sample4.xlsx', 'Sheet1', na_values=['NA'])

# comparison=datacompy.Compare(df1, df2, join_columns="POI ID")

comparison=datacompy.Compare(df1, df2, join_columns="PLOC",df1_name="sheet1",df2_name="sheet2")

# print(comparison.report())

print(comparison.report(sample_count=100000))

# compare.sample_mismatch(column="name", sample_count=1000)



Report = comparison.report(sample_count=100000)
csvFileToWrite=r'C:\Users\vchawla\Documents\AssesmentQuestions\google_referance_code\YouTubeReferance\resources\Output7.xls'
with open(csvFileToWrite,mode='r+',encoding='utf-8') as report_file:
    report_file.write(comparison.report(sample_count=100000))


# read_file = pd.read_csv (r'C:\Users\vchawla\Documents\AssesmentQuestions\google_referance_code\YouTubeReferance\resources\Difference1.txt')
# read_file.to_csv (r'C:\Users\vchawla\Documents\AssesmentQuestions\google_referance_code\YouTubeReferance\resources\Output1.xlsx', index=None)

