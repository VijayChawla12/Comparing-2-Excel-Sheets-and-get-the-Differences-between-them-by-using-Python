# pip install datacompy

import datacompy
import pandas as pd

# import datetime

# from pyspark.python.pyspark.shell import spark
# from pyspark.sql import Row

# df1=pd.read_excel("C:\Users\vchawla\Documents\Automation\Map Trowler Secondary Project 14 June\Comparing2ExcelSheets\sheet1.xlsx")
# df2=pd.read_excel("C:\Users\vchawla\Documents\Automation\Map Trowler Secondary Project 14 June\Comparing2ExcelSheets\sheet1.xlsx")

df1 = pd.read_excel(r'C:\Users\vchawla\Documents\AssesmentQuestions\google_referance_code\YouTubeReferance\resources\Sample1.xlsx', 'Sheet1', na_values=['NA'])
df2 = pd.read_excel(r'C:\Users\vchawla\Documents\AssesmentQuestions\google_referance_code\YouTubeReferance\resources\Sample2.xlsx', 'Sheet1', na_values=['NA'])

# covert string to an integer
# df2['PLOC'] = df2['PLOC'].astype(int)

# convert strint to an integer
# df2['PLOC'] = pd.to_numeric(df2['PLOC'], errors='ignore')

# pd.to_numeric(df2)

# convert all columns of DataFrame
df = df2.apply(pd.to_numeric, errors='coerce') # convert all columns of DataFrame

# convert just columns "a" and "b"
# df[["a", "b"]] = df[["a", "b"]].apply(pd.to_numeric)

# df2['mix_col'] = pd.to_numeric(df2['mix_col'], errors='coerce')

# comparison=datacompy.Compare(df1, df2, join_columns="POI ID")

# chunks = pd.DataFrame(df1, df2)

df1 = pd.DataFrame()
df2 = pd.DataFrame()
# c = pd.concat(a,b) # errors out:
# TypeError: first argument must be an iterable of pandas objects, you passed an object of type "DataFrame"

comparison = pd.concat([df1,df2], ignore_index=True) # works.


# comparison= pd.concat(df1, df2, ignore_index=True)



comparison=datacompy.Compare(df1, df2, join_columns="PLOC",df1_name="sheet1",df2_name="sheet2")

comparison.matches(ignore_extra_columns=False)

# comparison=pd.concat(df1, df2, join_columns="PLOC",df1_name="sheet1",df2_name="sheet2")

# print(comparison.report())


# base_df = spark.createDataFrame(df1)
# compare_df = spark.createDataFrame(df2)

# comparison = datacompy.SparkCompare(spark, base_df, compare_df, join_columns=['PLOC'])

# This prints out a human-readable report summarizing differences
comparison.report(sample_count=100000)


print(comparison.report(sample_count=100000))

# compare.sample_mismatch(column="name", sample_count=1000)



Report = comparison.report(sample_count=100000)
csvFileToWrite=r'C:\Users\vchawla\Documents\AssesmentQuestions\google_referance_code\YouTubeReferance\resources\Output6.xls'
with open(csvFileToWrite,mode='r+',encoding='utf-8') as report_file:
    report_file.write(comparison.report(sample_count=100000))


# read_file = pd.read_csv (r'C:\Users\vchawla\Documents\AssesmentQuestions\google_referance_code\YouTubeReferance\resources\Difference1.txt')
# read_file.to_csv (r'C:\Users\vchawla\Documents\AssesmentQuestions\google_referance_code\YouTubeReferance\resources\Output1.xlsx', index=None)

