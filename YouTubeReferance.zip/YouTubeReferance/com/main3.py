# pip install datacompy

import datacompy
import pandas as pd

# df1=pd.read_excel("C:\Users\vchawla\Documents\Automation\Map Trowler Secondary Project 14 June\Comparing2ExcelSheets\sheet1.xlsx")
# df2=pd.read_excel("C:\Users\vchawla\Documents\Automation\Map Trowler Secondary Project 14 June\Comparing2ExcelSheets\sheet1.xlsx")

df1 = pd.read_excel(r'C:\Users\vchawla\Documents\AssesmentQuestions\google_referance_code\YouTubeReferance\resources\Book11.xlsx', 'Sheet1', na_values=['NA'])
df2 = pd.read_excel(r'C:\Users\vchawla\Documents\AssesmentQuestions\google_referance_code\YouTubeReferance\resources\Book12.xlsx', 'Sheet1', na_values=['NA'])

# comparison=datacompy.Compare(df1, df2, join_columns="POI ID")

comparison=datacompy.Compare(df1, df2, join_columns="ID",df1_name="sheet1",df2_name="sheet2")

print(comparison.report())